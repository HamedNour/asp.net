﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace thefirst_project
{
    // Class for managing the library
    public class BookService : IBookService
    {
        private readonly List<Book> _books;

        public BookService(List<Book> books)
        {
            _books = books;
        }

        public void AddBook(Book book)
        {
            _books.Add(book);
        }

        public void DisplayBooks()
        {
            foreach (var book in _books)
            {
                Console.WriteLine($"Id: {book.Id}, Title: {book.Title}, Author: {book.Author}, Genre: {book.Genre}, Publication Year: {book.PublicationYear}");
            }
        }

        public int GetTotalBooks()
        {
            return _books.Count;
        }

        public void RemoveBook(string bookId)
        {
            if (int.TryParse(bookId, out int id))
            {
                _books.RemoveAll(book => book.Id == id);
            }
            else
            {
                Console.WriteLine("Invalid book ID format. Please provide a valid integer ID.");
            }
        }

        public List<Book> SearchBookByTitle(string title)
        {
            return _books.Where(book => book.Title.ToLower().Contains(title.ToLower())).ToList();
        }

    }
}