﻿using System;
using System.Collections.Generic;

namespace thefirst_project
{

    public class Program
    {
        static void Main(string[] args)
        {
            BookService library = new BookService(new List<Book>());

            try
            {
                Console.Write("Welcome !!!\nEnter your password: ");
                string password = Console.ReadLine();

                if (password == "01009030273")
                {
                    bool close = false;
                    while (!close)
                    {
                        Console.WriteLine("\nMenu\n" +
                        "1) Add book\n" +
                        "2) Remove book\n" +
                        "3) Search book by title\n" +
                        "4) Display books\n" +
                        "5) Get total books\n" +
                        "6) Close\n\n");
                        Console.Write("Choose your option from the menu: ");

                        if (int.TryParse(Console.ReadLine(), out int option))
                        {
                            switch (option)
                            {
                                case 1:
                                    AddBook(library);
                                    break;
                                case 2:
                                    RemoveBook(library);
                                    break;
                                case 3:
                                    SearchBookByTitle(library);
                                    break;
                                case 4:
                                    DisplayBooks(library);
                                    break;
                                case 5:
                                    GetTotalBooks(library);
                                    break;
                                case 6:
                                    Console.WriteLine("Thank you");
                                    close = true;
                                    break;
                                default:
                                    Console.WriteLine("Invalid option. Please try again.");
                                    break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid option. Please enter a number.");
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Invalid password");
                }

                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }

        static void AddBook(BookService library)
        {
            try
            {
                Console.WriteLine("Enter book details:");
                Console.Write("Id: ");
                int id = int.Parse(Console.ReadLine());
                Console.Write("Title: ");
                string title = Console.ReadLine();
                Console.Write("Author: ");
                string author = Console.ReadLine();
                Console.Write("Genre: ");
                string genre = Console.ReadLine();
                Console.Write("Publication Year: ");
                int publicationYear = int.Parse(Console.ReadLine());

                var newBook = new Book
                {
                    Id = id,
                    Title = title,
                    Author = author,
                    Genre = genre,
                    PublicationYear = publicationYear
                };

                library.AddBook(newBook);
                Console.WriteLine("Book added successfully.");
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid input. Please ensure all fields are filled correctly.");
            }
        }

        static void RemoveBook(BookService library)
        {
            Console.Write("Enter the book ID to remove: ");
            string bookIdToRemove = Console.ReadLine();
            library.RemoveBook(bookIdToRemove);
            Console.WriteLine("Book removed successfully.");
        }

        static void SearchBookByTitle(BookService library)
        {
            Console.Write("Enter the book title to search for: ");
            string titleToSearch = Console.ReadLine();
            List<Book> foundBooks = library.SearchBookByTitle(titleToSearch);
            if (foundBooks.Count > 0)
            {
                Console.WriteLine("Found book(s):");
                foreach (var book in foundBooks)
                {
                    Console.WriteLine($"Id: {book.Id}, Title: {book.Title}, Author: {book.Author}, Genre: {book.Genre}, Publication Year: {book.PublicationYear}");
                }
            }
            else
            {
                Console.WriteLine("No books found with the provided title.");
            }
        }


        static void DisplayBooks(BookService library)
        {
            Console.WriteLine("\nBooks in the library:");
            library.DisplayBooks();
        }

        static void GetTotalBooks(BookService library)
        {
            int totalBooks = library.GetTotalBooks();
            Console.WriteLine($"Total number of books in the library: {totalBooks}");
        }
    }
}