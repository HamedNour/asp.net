﻿using System.Collections.Generic;

namespace thefirst_project
{
    // انوس اخويا هنا عرفت انترفيس فيه كل الوظائف اللي استخدمتها
    public interface IBookService
    {
        void AddBook(Book book);
        void DisplayBooks();
        int GetTotalBooks();
        void RemoveBook(string bookId);
        List<Book> SearchBookByTitle(string title); // تعديل لتوافق الدالة المعدلة
    }

}
